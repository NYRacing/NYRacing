function blkStruct = slblocks
% Specify that the product should appear in the library browser
% and be cached in its repository
Browser.Library = 'mfeval_LIB';
Browser.Name    = 'MFeval Library';
blkStruct.Browser = Browser;