%Tire Parameters for front:
Bxf=17.156;
Cxf=1.406;
Dxf=1.2;
Byf=12.71;
Cyf=1.63;
Dyf=1.1;
%Tire Parameters for rear:
Bxr=17.156;
Cxr=1.406;
Dxr=1.2;
Byr=12.71;
Cyr=1.63;
Dyr=1.8;